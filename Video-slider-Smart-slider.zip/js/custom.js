var timer = 2000;
$(document).ready(function(){
        $(".item_wrapper .item:first-child").addClass("active");
        setTimeout(autoAddClass, timer);
		$('a.play_stop.play').css('display','none')

		var items = $('.best_slider_inner .item_wrapper .item').length;
		var activeindex = $('.item_wrapper .item.active').index() + 1;
		//alert(activeindex);
		var progresswidth = (100 * activeindex) / items;
		$('.progress-bar-inner').css('width', progresswidth + '%');


        next();
        prev();
        stop();
        play();

        fullscreen();

        //progressbar();

        //setTimeout(progressbar, timer);
        
});

function autoAddClass(){
    var next = $(".active").removeClass("active").next();
    if(next.length)
        $(next).addClass('active');
    else
        $('.item_wrapper .item:first-child').addClass('active');
    setTimeout(autoAddClass, timer);

    var items = $('.best_slider_inner .item_wrapper .item').length;
	var activeindex = $('.item_wrapper .item.active').index() + 1;
	//alert(activeindex);
	var progresswidth = (100 * activeindex) / items;
	$('.progress-bar-inner').css('width', progresswidth + '%');
}


function next(){
	$('a.next').on('click', function(e){
		
		var next1 = $(".active").removeClass("active").next();
	    if(next1.length)
	        $(next1).addClass('active');
	    else
	        $('.item_wrapper .item:first-child').addClass('active');
	});
}
function prev(){
	$('a.prev').on('click', function(e){
		
		var prev = $(".active").removeClass("active").prev();
	    if(prev.length)
	        $(prev).addClass('active');
	    else
	        $('.item_wrapper .item:last-child').addClass('active');
	});
}

function stop(){
	$('a.play_stop.stop').on('click', function(e){
		
		timer = 99999999999;

		$(this).css('display','none');
		// $(this).addClass('play');
		$('a.play_stop.play').css('display','inline-block');
	});
}
function play(){
	$('a.play_stop.play').on('click', function(even){
		
		timer = 2000;
		autoAddClass();

		$(this).css('display','none');
		// $(this).addClass('play');
		$('a.play_stop.stop').css('display','inline-block');
		 // $(this).removeClass('play');
		 // $(this).addClass('stop');
	});
}


function fullscreen(){
	// check native support
	// $('#support').text($.fullscreen.isNativelySupported() ? 'supports' : 'doesn\'t support');
	$('#fullscreen .exitfullscreen').hide();
	// open in fullscreen
	$('#fullscreen .requestfullscreen').click(function() {
		$('#fullscreen').fullscreen();
		return false;
	});

	// exit fullscreen
	$('#fullscreen .exitfullscreen').click(function() {
		$.fullscreen.exit();
		return false;
	});

	// document's event
	$(document).bind('fscreenchange', function(e, state, elem) {
		// if we currently in fullscreen mode
		if ($.fullscreen.isFullScreen()) {
			$('#fullscreen .requestfullscreen').hide();
			$('#fullscreen .exitfullscreen').show();
		} else {
			$('#fullscreen .requestfullscreen').show();
			$('#fullscreen .exitfullscreen').hide();
		}

		$('#state').text($.fullscreen.isFullScreen() ? '' : 'not');
	});
}
